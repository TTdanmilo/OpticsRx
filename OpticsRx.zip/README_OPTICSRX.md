# OpticsRx - 光学像差溯源自愈多智能体系统

## 项目概述

OpticsRx 是一个创新性的多智能体协同光学设计系统，通过长链推理与多 Agent 协作解决传统光学设计依赖专家经验的痛点问题。

## 核心痛点

- 传统光学设计依赖专家经验进行试错
- 难以在复杂像差（如高级球差与色差的耦合）中快速找到全局最优解
- 入门工程师试错成本高，迭代次数多

## 系统架构

### 四大智能体

1. **Monitor Agent** - 像差数据提取与监控
   - 从Zemax等光学设计软件中提取15项像差数据
   - 实时监控RMS波前误差和MTF等性能指标

2. **Strategist Agent** - 思维链推理与敏感度矩阵分析
   - 通过思维链反向追溯敏感度矩阵
   - 判断是曲率、厚度还是材料问题
   - 生成完整的推理链

3. **Executor Agent** - 参数调整沙盒
   - 在安全环境中调整光学系统参数
   - 生成参数调整建议
   - 应用调整并记录历史

4. **Critic Agent** - 物理模型闭环验证
   - 基于物理光学模型验证调整效果
   - 判断是否达到衍射极限
   - 提供反馈和学习建议

## 核心特性

- ✅ **15项像差全面监控**：从低级球差到高级球色差的完整覆盖
- ✅ **思维链推理**：透明的推理过程，可追溯问题根源
- ✅ **敏感度矩阵分析**：量化各参数对像差的影响
- ✅ **沙盒安全环境**：参数调整在安全环境中进行
- ✅ **闭环验证**：基于物理模型的效果验证
- ✅ **衍射极限检测**：自动判断是否达到光学系统理论极限

## 项目结构

```
opticsrx.py                 # 主程序文件
README_OPTICSRX.md          # 项目说明文档
opticsrx_report.json        # 运行报告（自动生成）
```

## 安装和运行

### 环境要求

- Python 3.8+
- NumPy

### 安装依赖

```bash
pip install numpy
```

### 运行示例

```bash
python opticsrx.py
```

## 使用示例

### 基本使用

```python
from opticsrx import OpticsRxSystem, create_demo_optical_system

# 创建光学系统
optical_system = create_demo_optical_system()

# 初始化OpticsRx
optics_rx = OpticsRxSystem(verbose=True)
optics_rx.initialize_system(optical_system, max_iterations=60)

# 运行优化
final_report = optics_rx.run_optimization()
```

### 自定义光学系统

```python
from opticsrx import OpticalSystem, OpticsRxSystem

# 定义自定义光学系统
surfaces = [
    {"curvature": 50.0, "thickness": 10.0, "material": "N-BK7"},
    {"curvature": -40.0, "thickness": 2.0, "material": "air"},
    # ... 更多表面
]

optical_system = OpticalSystem(
    surfaces=surfaces,
    materials=["N-BK7", "N-SF11", "air"],
    wavelengths=[0.486, 0.587, 0.656],
    field_angles=[0, 10, 20]
)

# 运行优化
optics_rx = OpticsRxSystem()
optics_rx.initialize_system(optical_system)
report = optics_rx.run_optimization()
```

## 性能指标

### 概念验证结果

- **人工设计**：约300次迭代收敛到衍射极限
- **Agent自动化**：约50次迭代收敛到衍射极限
- **迭代次数减少**：约83%
- **Token消耗**：约200万（根据实际模型）

### 监控的15项像差

1. 一级球差
2. 三级球差
3. 五级球差
4. X方向彗差
5. Y方向彗差
6. X方向像散
7. Y方向像散
8. 场曲
9. 畸变
10. 轴向色差
11. 横向色差
12. 珀兹伐和
13. 球色差
14. X方向倾斜
15. Y方向倾斜

## 与Zemax集成

在实际应用中，Monitor Agent可以通过以下方式与Zemax集成：

- Zemax COM接口（Windows）
- Zemax Python API
- ZPL宏脚本导出数据

```python
# 示例：Zemax集成（伪代码）
import win32com.client

class ZemaxMonitor(MonitorAgent):
    def __init__(self):
        super().__init__()
        self.zemax = win32com.client.Dispatch("Zemax.ZOSAPI_Application")
    
    def extract_aberration_data(self, optical_system, iteration):
        # 调用Zemax API获取像差数据
        # ... 实际Zemax集成代码
        pass
```

## 优化报告

系统会自动生成详细的优化报告（JSON格式），包含：

- 总迭代次数
- 总耗时
- Token使用量
- 初始和最终RMS波前误差
- MTF性能变化
- 改进历史
- 与人工设计的对比

## 技术亮点

1. **多Agent协同框架**：各Agent职责明确，协同高效
2. **思维链可解释性**：完整的推理过程，便于理解和调试
3. **敏感度矩阵分析**：量化分析，科学决策
4. **闭环验证机制**：确保优化方向正确
5. **衍射极限检测**：自动终止条件

## 扩展功能

可以进一步扩展的功能：

- 机器学习预测模型
- 多目标优化（同时优化多个视场）
- 温度和压力敏感度分析
- 公差分析集成
- 更多光学设计软件支持（Code V, OSLO等）

## 许可证

本项目为概念验证演示代码，仅供学习和研究使用。

---

**OpticsRx** - 让光学设计更智能、更高效 🚀
