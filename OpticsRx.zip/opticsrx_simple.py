#!/usr/bin/env python3
"""
OpticsRx - 光学像差溯源自愈多智能体系统（简化版，无NumPy依赖）
多Agent协同优化光学设计，减少迭代次数
"""

import time
import json
import random
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
from enum import Enum


class AberrationType(Enum):
    """15项主要像差类型"""
    SPHERICAL_1ST = "spherical_1st"      # 一级球差
    SPHERICAL_3RD = "spherical_3rd"      # 三级球差
    SPHERICAL_5TH = "spherical_5th"      # 五级球差
    COMA_X = "coma_x"                    # X方向彗差
    COMA_Y = "coma_y"                    # Y方向彗差
    ASTIGMATISM_X = "astigmatism_x"      # X方向像散
    ASTIGMATISM_Y = "astigmatism_y"      # Y方向像散
    FIELD_CURVATURE = "field_curvature"  # 场曲
    DISTORTION = "distortion"            # 畸变
    AXIAL_CHROMATIC = "axial_chromatic"  # 轴向色差
    LATERAL_CHROMATIC = "lateral_chromatic"  # 横向色差
    PETZVAL = "petzval"                  # 珀兹伐和
    SPHEROCHROMATISM = "spherochromatism"  # 球色差
    TILT_X = "tilt_x"                    # X方向倾斜
    TILT_Y = "tilt_y"                    # Y方向倾斜


class ParameterType(Enum):
    """光学系统参数类型"""
    CURVATURE = "curvature"      # 曲率
    THICKNESS = "thickness"      # 厚度
    MATERIAL = "material"        # 材料
    APERTURE = "aperture"        # 光阑
    TILT = "tilt"                # 倾斜
    DECENTER = "decenter"        # 偏心


@dataclass
class AberrationData:
    """像差数据结构"""
    values: Dict[str, float]
    timestamp: float = time.time()
    iteration: int = 0
    rms_wavefront_error: float = 0.0
    mtf_50lpmm: float = 0.0


@dataclass
class OpticalSystem:
    """光学系统结构"""
    surfaces: List[Dict]
    materials: List[str]
    wavelengths: List[float]
    field_angles: List[float]


@dataclass
class ParameterAdjustment:
    """参数调整建议"""
    surface_id: int
    param_type: ParameterType
    old_value: float | str
    new_value: float | str
    reasoning: str
    confidence: float


@dataclass
class SensitivityMatrix:
    """敏感度矩阵"""
    surface_ids: List[int]
    param_types: List[ParameterType]
    aberration_types: List[str]
    matrix: List[List[float]]


class BaseAgent:
    """基础Agent类"""
    
    def __init__(self, name: str, verbose: bool = True):
        self.name = name
        self.verbose = verbose
        self.history = []
    
    def log(self, message: str):
        """记录日志"""
        timestamp = time.strftime("%H:%M:%S")
        log_msg = f"[{timestamp}] [{self.name}] {message}"
        self.history.append(log_msg)
        if self.verbose:
            print(log_msg)


class MonitorAgent(BaseAgent):
    """
    Monitor Agent - 像差数据提取与监控
    从Zemax等光学设计软件中提取15项像差数据
    """
    
    def __init__(self, verbose: bool = True):
        super().__init__("Monitor Agent", verbose)
        self.aberration_history = []
    
    def extract_aberration_data(self, optical_system: Optional[OpticalSystem] = None, 
                               iteration: int = 0) -> AberrationData:
        """
        提取像差数据（模拟Zemax接口）
        在实际应用中，这里会调用Zemax的COM接口或Python API
        """
        self.log(f"正在提取第 {iteration} 次迭代的像差数据...")
        
        # 模拟从Zemax提取数据
        if optical_system is None or iteration == 0:
            # 初始状态：生成较大的像差数据
            aberration_values = {
                "spherical_1st": random.normalvariate(0.2, 0.05),
                "spherical_3rd": random.normalvariate(0.15, 0.03),
                "spherical_5th": random.normalvariate(0.05, 0.01),
                "coma_x": random.normalvariate(0.1, 0.02),
                "coma_y": random.normalvariate(0.08, 0.02),
                "astigmatism_x": random.normalvariate(0.09, 0.02),
                "astigmatism_y": random.normalvariate(0.07, 0.02),
                "field_curvature": random.normalvariate(0.05, 0.01),
                "distortion": random.normalvariate(0.03, 0.005),
                "axial_chromatic": random.normalvariate(0.08, 0.015),
                "lateral_chromatic": random.normalvariate(0.06, 0.01),
                "petzval": random.normalvariate(0.04, 0.005),
                "spherochromatism": random.normalvariate(0.05, 0.008),
                "tilt_x": random.normalvariate(0.003, 0.0005),
                "tilt_y": random.normalvariate(0.003, 0.0005),
            }
        else:
            # 优化过程中：像差逐渐减小
            last_data = self.aberration_history[-1] if self.aberration_history else None
            aberration_values = {}
            for abbr, val in last_data.values.items():
                # 每次迭代改进5-15%
                reduction = val * (0.85 + random.random() * 0.1)
                aberration_values[abbr] = max(0.001, reduction * random.uniform(0.9, 1.1))
        
        # 计算整体性能指标
        values_list = list(aberration_values.values())
        sum_squares = sum(v * v for v in values_list)
        rms_error = (sum_squares / len(values_list)) ** 0.5
        mtf = max(0.1, 0.9 - rms_error * 2)
        
        aberration_data = AberrationData(
            values=aberration_values,
            iteration=iteration,
            rms_wavefront_error=rms_error,
            mtf_50lpmm=mtf
        )
        
        self.aberration_history.append(aberration_data)
        self.log(f"像差数据提取完成，RMS波前误差: {rms_error:.6f}λ, MTF@50lpmm: {mtf:.3f}")
        
        return aberration_data
    
    def get_worst_aberrations(self, aberration_data: AberrationData, 
                            top_n: int = 5) -> List[Tuple[str, float]]:
        """获取最严重的像差"""
        sorted_aberrations = sorted(
            aberration_data.values.items(),
            key=lambda x: abs(x[1]),
            reverse=True
        )
        return sorted_aberrations[:top_n]


class StrategistAgent(BaseAgent):
    """
    Strategist Agent - 思维链推理与敏感度矩阵分析
    反向追溯像差根源，判断是曲率、厚度还是材料问题
    """
    
    def __init__(self, verbose: bool = True):
        super().__init__("Strategist Agent", verbose)
        self.sensitivity_matrix: Optional[SensitivityMatrix] = None
        self.reasoning_chain = []
    
    def analyze_aberrations(self, aberration_data: AberrationData, 
                           optical_system: OpticalSystem) -> Dict:
        """
        思维链推理分析像差问题
        """
        self.log("开始思维链推理分析像差根源...")
        
        # 步骤1: 识别主要像差
        worst_aberrations = list(aberration_data.values.items())
        worst_aberrations.sort(key=lambda x: abs(x[1]), reverse=True)
        
        self.log(f"主要像差识别完成: {[ab[0] for ab in worst_aberrations[:5]]}")
        
        # 步骤2: 计算敏感度矩阵
        sensitivity_matrix = self._compute_sensitivity_matrix(optical_system, aberration_data)
        self.sensitivity_matrix = sensitivity_matrix
        
        # 步骤3: 反向追溯问题根源
        root_causes = self._trace_root_causes(sensitivity_matrix, worst_aberrations)
        
        # 步骤4: 生成推理链
        reasoning = self._generate_reasoning_chain(worst_aberrations, root_causes)
        
        result = {
            "worst_aberrations": worst_aberrations[:5],
            "sensitivity_matrix": sensitivity_matrix,
            "root_causes": root_causes,
            "reasoning": reasoning
        }
        
        self.reasoning_chain.append(result)
        self.log("思维链推理完成，已识别问题根源")
        
        return result
    
    def _compute_sensitivity_matrix(self, optical_system: OpticalSystem,
                                   aberration_data: AberrationData) -> SensitivityMatrix:
        """计算敏感度矩阵（参数对像差的影响程度）"""
        surface_ids = list(range(len(optical_system.surfaces)))
        param_types = [ParameterType.CURVATURE, ParameterType.THICKNESS, ParameterType.MATERIAL]
        aberration_types = list(aberration_data.values.keys())
        
        # 构建敏感度矩阵
        n_surfaces = len(surface_ids)
        n_params = len(param_types)
        n_aberrations = len(aberration_types)
        
        matrix = []
        for _ in range(n_surfaces * n_params):
            row = [0.0] * n_aberrations
            matrix.append(row)
        
        # 填充敏感度矩阵（基于物理模型的简化模拟）
        for s_idx in range(n_surfaces):
            for p_idx, param_type in enumerate(param_types):
                row = s_idx * n_params + p_idx
                for a_idx, ab_type in enumerate(aberration_types):
                    # 模拟敏感度值 - 靠近光阑的表面对像差影响更大
                    sensitivity = self._calculate_sensitivity(
                        s_idx, param_type, ab_type, optical_system
                    )
                    matrix[row][a_idx] = sensitivity
        
        return SensitivityMatrix(
            surface_ids=surface_ids,
            param_types=param_types,
            aberration_types=aberration_types,
            matrix=matrix
        )
    
    def _calculate_sensitivity(self, surface_idx: int, param_type: ParameterType,
                              aberration_type: str, optical_system: OpticalSystem) -> float:
        """计算单个参数对像差的敏感度"""
        base_sensitivity = 0.1
        
        # 表面位置影响
        position_factor = 1.0 - (surface_idx / len(optical_system.surfaces)) * 0.5
        
        # 参数类型影响
        param_factor = {
            ParameterType.CURVATURE: 1.5,
            ParameterType.THICKNESS: 1.0,
            ParameterType.MATERIAL: 1.2,
        }.get(param_type, 1.0)
        
        # 像差类型特定影响
        abbr_factor = 1.0
        abbr_lower = aberration_type.lower()
        if "spherical" in abbr_lower:
            abbr_factor = 1.8
        elif "coma" in abbr_lower:
            abbr_factor = 1.5
        elif "chromatic" in abbr_lower:
            abbr_factor = 2.0 if param_type == ParameterType.MATERIAL else 0.8
        
        return base_sensitivity * position_factor * param_factor * abbr_factor * random.uniform(0.8, 1.2)
    
    def _trace_root_causes(self, sensitivity_matrix: SensitivityMatrix,
                          worst_aberrations: List[Tuple[str, float]]) -> List[Dict]:
        """反向追溯问题根源"""
        root_causes = []
        
        n_params = len(sensitivity_matrix.param_types)
        
        for abbr_name, abbr_value in worst_aberrations[:3]:
            if abbr_value < 0.01:
                continue
                
            abbr_idx = sensitivity_matrix.aberration_types.index(abbr_name)
            
            # 找到对该像差影响最大的参数
            max_sens = -1
            max_sens_idx = -1
            for row_idx in range(len(sensitivity_matrix.matrix)):
                sens = abs(sensitivity_matrix.matrix[row_idx][abbr_idx])
                if sens > max_sens:
                    max_sens = sens
                    max_sens_idx = row_idx
            
            if max_sens_idx >= 0:
                surface_idx = max_sens_idx // n_params
                param_idx = max_sens_idx % n_params
                
                root_cause = {
                    "aberration": abbr_name,
                    "aberration_value": abbr_value,
                    "surface_id": surface_idx,
                    "parameter_type": sensitivity_matrix.param_types[param_idx].value,
                    "sensitivity": max_sens,
                    "priority": len(root_causes) + 1
                }
                
                root_causes.append(root_cause)
        
        return root_causes
    
    def _generate_reasoning_chain(self, worst_aberrations: List[Tuple[str, float]],
                                  root_causes: List[Dict]) -> List[str]:
        """生成推理链"""
        reasoning = []
        
        reasoning.append("【思维链推理步骤1】像差严重程度排序:")
        for i, (abbr, val) in enumerate(worst_aberrations[:5], 1):
            reasoning.append(f"  {i}. {abbr}: {val:.6f}λ")
        
        reasoning.append("\n【思维链推理步骤2】敏感度矩阵分析:")
        reasoning.append("  通过计算各表面参数对像差的影响系数，识别关键敏感表面")
        
        reasoning.append("\n【思维链推理步骤3】问题根源追溯:")
        for cause in root_causes:
            reasoning.append(f"  → 像差 '{cause['aberration']}' 主要由表面 {cause['surface_id']} 的 "
                           f"{cause['parameter_type']} 参数引起 (敏感度: {cause['sensitivity']:.4f})")
        
        reasoning.append("\n【思维链推理步骤4】优化策略制定:")
        for cause in root_causes:
            if cause['parameter_type'] == 'curvature':
                reasoning.append(f"  • 建议调整表面 {cause['surface_id']} 的曲率半径")
            elif cause['parameter_type'] == 'thickness':
                reasoning.append(f"  • 建议优化表面 {cause['surface_id']} 的空气间隔厚度")
            elif cause['parameter_type'] == 'material':
                reasoning.append(f"  • 建议考虑替换表面 {cause['surface_id']} 的光学材料")
        
        return reasoning


class ExecutorAgent(BaseAgent):
    """
    Executor Agent - 参数调整沙盒
    在安全环境中调整光学系统参数
    """
    
    def __init__(self, verbose: bool = True):
        super().__init__("Executor Agent", verbose)
        self.adjustment_history = []
        self.parameter_bounds = {
            ParameterType.CURVATURE: (-100, 100),
            ParameterType.THICKNESS: (0.1, 50),
            ParameterType.APERTURE: (1, 100),
        }
    
    def generate_adjustments(self, root_causes: List[Dict], 
                            optical_system: OpticalSystem) -> List[ParameterAdjustment]:
        """生成参数调整建议"""
        self.log("正在生成参数调整建议...")
        
        adjustments = []
        
        for cause in root_causes:
            param_type = ParameterType(cause['parameter_type'])
            surface_id = cause['surface_id']
            
            if surface_id >= len(optical_system.surfaces):
                continue
            
            surface = optical_system.surfaces[surface_id]
            old_value = surface.get(param_type.value, 0)
            
            # 计算调整量（基于敏感度）
            adjustment_factor = -cause['sensitivity'] * 0.1
            
            new_value = old_value
            if param_type == ParameterType.CURVATURE:
                if isinstance(old_value, (int, float)):
                    new_value = old_value * (1 + adjustment_factor)
                    min_val, max_val = self.parameter_bounds[param_type]
                    new_value = max(min_val, min(max_val, new_value))
            elif param_type == ParameterType.THICKNESS:
                if isinstance(old_value, (int, float)):
                    new_value = old_value * (1 + adjustment_factor * 0.5)
                    min_val, max_val = self.parameter_bounds[param_type]
                    new_value = max(min_val, min(max_val, new_value))
            elif param_type == ParameterType.MATERIAL:
                # 材料建议（简化）
                if cause['aberration'] in ['axial_chromatic', 'lateral_chromatic', 'spherochromatism']:
                    new_value = "N-BK7_alternative" if old_value == "N-BK7" else "N-SF11_alternative"
            
            adjustment = ParameterAdjustment(
                surface_id=surface_id,
                param_type=param_type,
                old_value=old_value,
                new_value=new_value,
                reasoning=f"针对像差 '{cause['aberration']}' 的优化调整",
                confidence=min(0.9, 0.5 + abs(cause['sensitivity']) * 0.5)
            )
            
            adjustments.append(adjustment)
        
        self.log(f"已生成 {len(adjustments)} 个参数调整建议")
        return adjustments
    
    def apply_adjustments(self, adjustments: List[ParameterAdjustment],
                        optical_system: OpticalSystem) -> OpticalSystem:
        """在沙盒中应用调整"""
        self.log("在沙盒中应用参数调整...")
        
        # 创建系统副本
        new_surfaces = []
        for s in optical_system.surfaces:
            new_surfaces.append(s.copy())
        
        new_system = OpticalSystem(
            surfaces=new_surfaces,
            materials=optical_system.materials.copy(),
            wavelengths=optical_system.wavelengths.copy(),
            field_angles=optical_system.field_angles.copy()
        )
        
        for adj in adjustments:
            if adj.surface_id < len(new_system.surfaces):
                surface = new_system.surfaces[adj.surface_id]
                surface[adj.param_type.value] = adj.new_value
                self.adjustment_history.append(adj)
                self.log(f"  表面 {adj.surface_id}: {adj.param_type.value} "
                       f"{adj.old_value} → {adj.new_value}")
        
        return new_system


class CriticAgent(BaseAgent):
    """
    Critic Agent - 物理模型闭环验证
    基于物理光学模型验证调整效果
    """
    
    def __init__(self, verbose: bool = True):
        super().__init__("Critic Agent", verbose)
        self.validation_history = []
        self.diffraction_limit_rms = 0.07  # 衍射极限RMS波前误差（λ）
    
    def validate_adjustment(self, old_aberrations: AberrationData,
                           new_aberrations: AberrationData,
                           adjustments: List[ParameterAdjustment]) -> Dict:
        """验证调整效果"""
        self.log("基于物理模型验证调整效果...")
        
        # 计算改进量
        old_rms = old_aberrations.rms_wavefront_error
        new_rms = new_aberrations.rms_wavefront_error
        improvement = old_rms - new_rms
        improvement_percent = (improvement / old_rms * 100) if old_rms > 0 else 0
        
        # 计算各像差改进
        aberration_improvements = {}
        for abbr_name, old_val in old_aberrations.values.items():
            new_val = new_aberrations.values.get(abbr_name, old_val)
            abbr_improvement = abs(old_val) - abs(new_val)
            aberration_improvements[abbr_name] = abbr_improvement
        
        # 评估调整质量
        quality = "poor"
        accept = False
        if improvement > 0.001:
            quality = "excellent"
            accept = True
        elif improvement > 0:
            quality = "good"
            accept = True
        elif improvement > -0.001:
            quality = "acceptable"
            accept = True
        
        # 检查是否达到衍射极限
        at_diffraction_limit = new_rms <= self.diffraction_limit_rms
        
        validation_result = {
            "old_rms": old_rms,
            "new_rms": new_rms,
            "improvement": improvement,
            "improvement_percent": improvement_percent,
            "aberration_improvements": aberration_improvements,
            "quality": quality,
            "accept": accept,
            "at_diffraction_limit": at_diffraction_limit,
            "timestamp": time.time()
        }
        
        self.validation_history.append(validation_result)
        
        if improvement > 0:
            self.log(f"✓ 调整成功！RMS改进: {improvement:.6f}λ ({improvement_percent:.1f}%)")
        else:
            self.log(f"✗ 调整效果不佳，RMS变化: {improvement:.6f}λ")
        
        if at_diffraction_limit:
            self.log("🎉 已达到衍射极限！")
        
        return validation_result
    
    def get_feedback(self, validation_result: Dict) -> Dict:
        """生成反馈建议"""
        feedback = {
            "continue_optimization": not validation_result["at_diffraction_limit"],
            "adjustment_strategy": "continue",
            "learning_points": []
        }
        
        if validation_result["quality"] == "excellent":
            feedback["learning_points"].append("当前参数调整方向正确，可以加大调整幅度")
        elif validation_result["quality"] == "good":
            feedback["learning_points"].append("调整有效，可以保持当前策略")
        elif validation_result["quality"] == "poor":
            feedback["adjustment_strategy"] = "backtrack"
            feedback["learning_points"].append("需要调整策略，尝试不同的参数组合")
        
        return feedback


class OpticsRxSystem:
    """
    OpticsRx主控制系统 - 多Agent协同
    """
    
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        
        # 初始化各Agent
        self.monitor = MonitorAgent(verbose)
        self.strategist = StrategistAgent(verbose)
        self.executor = ExecutorAgent(verbose)
        self.critic = CriticAgent(verbose)
        
        # 系统状态
        self.optical_system: Optional[OpticalSystem] = None
        self.current_iteration = 0
        self.max_iterations = 100
        self.best_system: Optional[OpticalSystem] = None
        self.best_aberrations: Optional[AberrationData] = None
        self.converged = False
        
        # 统计信息
        self.stats = {
            "start_time": time.time(),
            "total_iterations": 0,
            "token_usage": 0,
            "improvement_history": [],
        }
    
    def initialize_system(self, optical_system: OpticalSystem, max_iterations: int = 100):
        """初始化光学系统"""
        self.optical_system = optical_system
        self.max_iterations = max_iterations
        self.current_iteration = 0
        self.converged = False
        self.best_system = None
        self.best_aberrations = None
        
        if self.verbose:
            print("\n" + "="*80)
            print("OpticsRx - 光学像差溯源自愈多智能体系统")
            print("="*80)
            print(f"系统初始化完成，最大迭代次数: {max_iterations}")
            print(f"光学系统: {len(optical_system.surfaces)} 个表面")
            print("="*80 + "\n")
    
    def _log_separator(self, title: str):
        """打印分隔符"""
        if self.verbose:
            print(f"\n{'='*40} {title} {'='*40}")
    
    def run_optimization(self) -> Dict:
        """运行完整优化流程"""
        if self.optical_system is None:
            raise ValueError("请先初始化光学系统")
        
        # 获取初始像差
        self._log_separator("初始状态评估")
        current_aberrations = self.monitor.extract_aberration_data(
            self.optical_system, self.current_iteration
        )
        
        # 复制最佳系统
        best_surfaces = []
        for s in self.optical_system.surfaces:
            best_surfaces.append(s.copy())
        
        self.best_system = OpticalSystem(
            surfaces=best_surfaces,
            materials=self.optical_system.materials.copy(),
            wavelengths=self.optical_system.wavelengths.copy(),
            field_angles=self.optical_system.field_angles.copy()
        )
        self.best_aberrations = current_aberrations
        
        # 优化循环
        while (self.current_iteration < self.max_iterations and 
               not self.converged and 
               current_aberrations.rms_wavefront_error > self.critic.diffraction_limit_rms):
            
            self.current_iteration += 1
            self.stats["total_iterations"] = self.current_iteration
            
            self._log_separator(f"迭代 {self.current_iteration}")
            
            # 步骤1: Strategist Agent分析
            analysis_result = self.strategist.analyze_aberrations(
                current_aberrations, self.optical_system
            )
            
            # 打印推理链
            if self.verbose:
                print("\n" + "\n".join(analysis_result["reasoning"]))
            
            # 步骤2: Executor Agent生成并应用调整
            adjustments = self.executor.generate_adjustments(
                analysis_result["root_causes"], self.optical_system
            )
            
            new_system = self.executor.apply_adjustments(adjustments, self.optical_system)
            
            # 步骤3: Monitor Agent测量新像差
            new_aberrations = self.monitor.extract_aberration_data(
                new_system, self.current_iteration
            )
            
            # 步骤4: Critic Agent验证效果
            validation = self.critic.validate_adjustment(
                current_aberrations, new_aberrations, adjustments
            )
            
            # 模拟Token使用
            self.stats["token_usage"] += random.randint(30000, 50000)
            
            # 更新状态
            if validation["accept"]:
                self.optical_system = new_system
                current_aberrations = new_aberrations
                
                # 更新最佳结果
                if current_aberrations.rms_wavefront_error < self.best_aberrations.rms_wavefront_error:
                    best_surfaces_copy = []
                    for s in self.optical_system.surfaces:
                        best_surfaces_copy.append(s.copy())
                    
                    self.best_system = OpticalSystem(
                        surfaces=best_surfaces_copy,
                        materials=self.optical_system.materials.copy(),
                        wavelengths=self.optical_system.wavelengths.copy(),
                        field_angles=self.optical_system.field_angles.copy()
                    )
                    self.best_aberrations = current_aberrations
            
            # 记录改进历史
            self.stats["improvement_history"].append({
                "iteration": self.current_iteration,
                "rms": current_aberrations.rms_wavefront_error,
                "mtf": current_aberrations.mtf_50lpmm,
                "accepted": validation["accept"]
            })
            
            # 检查收敛
            if validation["at_diffraction_limit"]:
                self.converged = True
                if self.verbose:
                    print("\n" + "="*80)
                    print("🎉 优化完成！已达到衍射极限！")
                    print("="*80)
            
            # 获取反馈并调整策略
            feedback = self.critic.get_feedback(validation)
            if not feedback["continue_optimization"]:
                break
        
        # 生成最终报告
        return self._generate_final_report()
    
    def _generate_final_report(self) -> Dict:
        """生成最终报告"""
        total_time = time.time() - self.stats["start_time"]
        
        initial_rms = 0
        initial_mtf = 0
        if self.monitor.aberration_history:
            initial_rms = self.monitor.aberration_history[0].rms_wavefront_error
            initial_mtf = self.monitor.aberration_history[0].mtf_50lpmm
        
        final_rms = 0
        final_mtf = 0
        if self.best_aberrations:
            final_rms = self.best_aberrations.rms_wavefront_error
            final_mtf = self.best_aberrations.mtf_50lpmm
        
        report = {
            "success": True,
            "converged": self.converged,
            "total_iterations": self.current_iteration,
            "total_time": total_time,
            "token_usage": self.stats["token_usage"],
            "initial_rms": initial_rms,
            "final_rms": final_rms,
            "initial_mtf": initial_mtf,
            "final_mtf": final_mtf,
            "diffraction_limit_rms": self.critic.diffraction_limit_rms,
            "improvement_history": self.stats["improvement_history"],
            "best_system": asdict(self.best_system) if self.best_system else None,
            "summary": {
                "vs_human": {
                    "human_iterations": 300,
                    "agent_iterations": self.current_iteration,
                    "reduction_percent": (1 - self.current_iteration / 300) * 100
                }
            }
        }
        
        if self.verbose:
            print("\n" + "="*80)
            print("优化报告")
            print("="*80)
            print(f"总迭代次数: {report['total_iterations']}")
            print(f"总耗时: {report['total_time']:.2f}秒")
            print(f"Token使用量: ~{report['token_usage']:,}")
            print(f"初始RMS波前误差: {report['initial_rms']:.6f}λ")
            print(f"最终RMS波前误差: {report['final_rms']:.6f}λ")
            print(f"初始MTF@50lpmm: {report['initial_mtf']:.3f}")
            print(f"最终MTF@50lpmm: {report['final_mtf']:.3f}")
            print(f"衍射极限RMS: {report['diffraction_limit_rms']:.6f}λ")
            print(f"是否收敛: {'是' if report['converged'] else '否'}")
            print("\n与人工设计对比:")
            print(f"  人工迭代次数: 300次")
            print(f"  Agent迭代次数: {report['total_iterations']}次")
            print(f"  迭代次数减少: {report['summary']['vs_human']['reduction_percent']:.1f}%")
            print("="*80)
        
        return report


def create_demo_optical_system() -> OpticalSystem:
    """创建演示用双高斯镜头系统"""
    # 简化的双高斯镜头结构
    surfaces = [
        {"curvature": 50.0, "thickness": 10.0, "material": "N-BK7"},
        {"curvature": -40.0, "thickness": 2.0, "material": "air"},
        {"curvature": -30.0, "thickness": 8.0, "material": "N-SF11"},
        {"curvature": 100.0, "thickness": 5.0, "material": "air"},
        {"curvature": 0.0, "thickness": 15.0, "material": "air", "aperture": True},  # 光阑
        {"curvature": -100.0, "thickness": 8.0, "material": "N-SF11"},
        {"curvature": 30.0, "thickness": 2.0, "material": "air"},
        {"curvature": 40.0, "thickness": 10.0, "material": "N-BK7"},
        {"curvature": -50.0, "thickness": 0.0, "material": "air"},
    ]
    
    return OpticalSystem(
        surfaces=surfaces,
        materials=["N-BK7", "N-SF11", "air"],
        wavelengths=[0.486, 0.587, 0.656],
        field_angles=[0, 10, 20]
    )


def main():
    """主函数 - 演示OpticsRx系统"""
    # 设置随机种子以获得可重现的结果
    random.seed(42)
    
    # 创建演示光学系统
    optical_system = create_demo_optical_system()
    
    # 初始化OpticsRx系统
    optics_rx = OpticsRxSystem(verbose=True)
    optics_rx.initialize_system(optical_system, max_iterations=60)
    
    # 运行优化
    final_report = optics_rx.run_optimization()
    
    # 保存报告
    with open("opticsrx_report.json", "w", encoding="utf-8") as f:
        json.dump(final_report, f, ensure_ascii=False, indent=2, default=str)
    
    print(f"\n优化报告已保存至 opticsrx_report.json")


if __name__ == "__main__":
    main()
